module Main where

import Ex05

main = sumFile
